import React from 'react'

const Ball = () => {
  return (
    <div>Ball</div>
  )
}

export default Ball