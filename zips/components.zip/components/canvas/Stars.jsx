import React from 'react'

const Stars = () => {
  return (
    <div>Stars</div>
  )
}

export default Stars